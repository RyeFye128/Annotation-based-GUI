SEfall2014
==========
<<<<<<< HEAD
=======
Group Project for Dr. Ding's Software Engineering I class.

Group Members
- Kyle Williamson
- Timothy Johnson
- Dillon Roberts
- Aaron Harris
- Gregory Jenkins
- James Tyson
- Michael Fisher
- Ryan Chartier
- Thomas Lehman
- Nam Thai
